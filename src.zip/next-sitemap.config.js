/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: 'https://cabexpert.co',
  generateRobotsTxt: true, // (optional)
  // ...other options
}